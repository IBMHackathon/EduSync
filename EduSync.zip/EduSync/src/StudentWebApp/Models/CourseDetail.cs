﻿using System;
using System.Collections.Generic;

namespace EduSync.Models
{
    public partial class CourseDetail
    {
        public int CourseDetailId { get; set; }
        public int? CourseId { get; set; }
        public int SubjectId { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public virtual Course Course { get; set; }
        public virtual Subject Subject { get; set; }
    }
}
