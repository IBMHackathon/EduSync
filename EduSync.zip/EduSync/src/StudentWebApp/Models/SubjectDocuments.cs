﻿using System;
using System.Collections.Generic;

namespace EduSync.Models
{
    public partial class SubjectDocuments
    {
        public int SubjectDocumentId { get; set; }
        public int? SubjectId { get; set; }
        public string DocumentUrl { get; set; }
        public string Author { get; set; }
        public DateTime? CreatedDate { get; set; }

        public virtual Subject Subject { get; set; }
    }
}
