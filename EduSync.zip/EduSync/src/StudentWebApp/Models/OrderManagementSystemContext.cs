﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace EduSync.Models
{
    public partial class OrderManagementSystemContext : DbContext
    {
        public OrderManagementSystemContext()
        {
        }

        public OrderManagementSystemContext(DbContextOptions<OrderManagementSystemContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Course> Course { get; set; }
        public virtual DbSet<CourseDetail> CourseDetail { get; set; }
        public virtual DbSet<Geography> Geography { get; set; }
        public virtual DbSet<Student> Student { get; set; }
        public virtual DbSet<Subject> Subject { get; set; }
        public virtual DbSet<SubjectCategory> SubjectCategory { get; set; }
        public virtual DbSet<SubjectDocuments> SubjectDocuments { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                //optionsBuilder.UseSqlServer("Server=tcp:selfservices.database.windows.net,1433;Initial Catalog=OrderManagementSystem;Persist Security Info=False;User ID=sqllogin;Password=Infy123+;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.0-rtm-35687");

            modelBuilder.Entity<Course>(entity =>
            {
                entity.ToTable("Course", "MyCoach");

                entity.Property(e => e.CourseId)
                    .HasColumnName("CourseID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Comment).HasMaxLength(128);

                entity.Property(e => e.CourseName).HasMaxLength(10);

                entity.Property(e => e.OrderDate).HasColumnType("datetime");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.Course)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CourseHeader_Student");
            });

            modelBuilder.Entity<CourseDetail>(entity =>
            {
                entity.ToTable("CourseDetail", "MyCoach");

                entity.Property(e => e.CourseDetailId)
                    .HasColumnName("CourseDetailID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.SubjectId).HasColumnName("SubjectID");

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.CourseDetail)
                    .HasForeignKey(d => d.CourseId)
                    .HasConstraintName("FK_CourseDetail_Course");

                entity.HasOne(d => d.Subject)
                    .WithMany(p => p.CourseDetail)
                    .HasForeignKey(d => d.SubjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CourseDetail_Subject");
            });

            modelBuilder.Entity<Geography>(entity =>
            {
                entity.ToTable("Geography", "MyCoach");

                entity.Property(e => e.GeographyId).HasColumnName("GeographyID");

                entity.Property(e => e.City).HasMaxLength(30);

                entity.Property(e => e.CountryRegionCode).HasMaxLength(3);

                entity.Property(e => e.IpAddressLocator).HasMaxLength(15);

                entity.Property(e => e.PostalCode).HasMaxLength(15);

                entity.Property(e => e.StateProvinceName).HasMaxLength(50);
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.ToTable("Student", "MyCoach");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.AddressLine1).HasMaxLength(120);

                entity.Property(e => e.AddressLine2).HasMaxLength(120);

                entity.Property(e => e.BirthDate).HasColumnType("date");

                entity.Property(e => e.CommuteDistance).HasMaxLength(15);

                entity.Property(e => e.EmailAddress).HasMaxLength(50);

                entity.Property(e => e.FirstName).HasMaxLength(50);

                entity.Property(e => e.Gender).HasMaxLength(1);

                entity.Property(e => e.GeographyId).HasColumnName("GeographyID");

                entity.Property(e => e.LastName).HasMaxLength(50);

                entity.Property(e => e.MaritalStatus).HasMaxLength(1);

                entity.Property(e => e.MiddleName).HasMaxLength(50);

                entity.Property(e => e.Phone).HasMaxLength(20);

                entity.Property(e => e.Suffix).HasMaxLength(10);

                entity.Property(e => e.Title).HasMaxLength(8);

                entity.HasOne(d => d.Geography)
                    .WithMany(p => p.Student)
                    .HasForeignKey(d => d.GeographyId)
                    .HasConstraintName("FK_Student_Geography");
            });

            modelBuilder.Entity<Subject>(entity =>
            {
                entity.ToTable("Subject", "MyCoach");

                entity.Property(e => e.SubjectId).HasColumnName("SubjectID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Status).HasMaxLength(7);

                entity.Property(e => e.SubjectCategoryId).HasColumnName("SubjectCategoryID");

                entity.HasOne(d => d.SubjectCategory)
                    .WithMany(p => p.Subject)
                    .HasForeignKey(d => d.SubjectCategoryId)
                    .HasConstraintName("FK_Subject_SubjectCategory");
            });

            modelBuilder.Entity<SubjectCategory>(entity =>
            {
                entity.ToTable("SubjectCategory", "MyCoach");

                entity.Property(e => e.SubjectCategoryId).HasColumnName("SubjectCategoryID");

                entity.Property(e => e.CategoryName).HasMaxLength(100);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<SubjectDocuments>(entity =>
            {
                entity.HasKey(e => e.SubjectDocumentId);

                entity.ToTable("SubjectDocuments", "MyCoach");

                entity.Property(e => e.SubjectDocumentId)
                    .HasColumnName("SubjectDocumentID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Author)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.DocumentUrl)
                    .HasColumnName("DocumentURL")
                    .IsUnicode(false);

                entity.Property(e => e.SubjectId).HasColumnName("SubjectID");

                entity.HasOne(d => d.Subject)
                    .WithMany(p => p.SubjectDocuments)
                    .HasForeignKey(d => d.SubjectId)
                    .HasConstraintName("FK_SubjectDocuments_Subject");
            });
        }
    }
}
