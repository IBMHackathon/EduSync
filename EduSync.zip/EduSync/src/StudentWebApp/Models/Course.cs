﻿using System;
using System.Collections.Generic;

namespace EduSync.Models
{
    public partial class Course
    {
        public Course()
        {
            CourseDetail = new HashSet<CourseDetail>();
        }

        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public DateTime OrderDate { get; set; }
        public byte Status { get; set; }
        public int StudentId { get; set; }
        public string Comment { get; set; }

        public virtual Student Student { get; set; }
        public virtual ICollection<CourseDetail> CourseDetail { get; set; }
    }
}
