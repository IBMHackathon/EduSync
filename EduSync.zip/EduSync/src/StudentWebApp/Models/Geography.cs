﻿using System;
using System.Collections.Generic;

namespace EduSync.Models
{
    public partial class Geography
    {
        public Geography()
        {
            Student = new HashSet<Student>();
        }

        public int GeographyId { get; set; }
        public string City { get; set; }
        public string StateProvinceName { get; set; }
        public string CountryRegionCode { get; set; }
        public string PostalCode { get; set; }
        public string IpAddressLocator { get; set; }

        public virtual ICollection<Student> Student { get; set; }
    }
}
