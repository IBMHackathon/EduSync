﻿using System;
using System.Collections.Generic;

namespace EduSync.Models
{
    public partial class Student
    {
        public Student()
        {
            Course = new HashSet<Course>();
        }

        public int StudentId { get; set; }
        public int? GeographyId { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public bool? NameStyle { get; set; }
        public DateTime? BirthDate { get; set; }
        public string MaritalStatus { get; set; }
        public string Suffix { get; set; }
        public string Gender { get; set; }
        public string EmailAddress { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string Phone { get; set; }
        public string CommuteDistance { get; set; }

        public virtual Geography Geography { get; set; }
        public virtual ICollection<Course> Course { get; set; }
    }
}
