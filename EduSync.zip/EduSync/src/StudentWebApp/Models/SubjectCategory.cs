﻿using System;
using System.Collections.Generic;

namespace EduSync.Models
{
    public partial class SubjectCategory
    {
        public SubjectCategory()
        {
            Subject = new HashSet<Subject>();
        }

        public int SubjectCategoryId { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }

        public virtual ICollection<Subject> Subject { get; set; }
    }
}
