﻿using System;
using System.Collections.Generic;

namespace EduSync.Models
{
    public partial class Subject
    {
        public Subject()
        {
            CourseDetail = new HashSet<CourseDetail>();
            SubjectDocuments = new HashSet<SubjectDocuments>();
        }

        public int SubjectId { get; set; }
        public int? SubjectCategoryId { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }

        public virtual SubjectCategory SubjectCategory { get; set; }
        public virtual ICollection<CourseDetail> CourseDetail { get; set; }
        public virtual ICollection<SubjectDocuments> SubjectDocuments { get; set; }
    }
}
